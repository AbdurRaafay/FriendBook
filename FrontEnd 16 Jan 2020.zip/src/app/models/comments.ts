export class Comment
{    
    fullName: string;
    text: string;
    timestamp: Date;
    imagePath: string;
}