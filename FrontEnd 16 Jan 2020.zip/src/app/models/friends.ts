export class Friends
{    
    fullName: string;
    onlinestatus: boolean;
    imagePath: string;
}